Optional: DXVK (runs the game's DirectX 9 through Vulkan - smoother frames on many AMD cards)
1. Download DXVK from https://github.com/doitsujin/dxvk/releases and copy x32\d3d9.dll into the game folder
   (next to FalloutNV.exe). If you use ENB/ENBoost, rename its d3d9.dll to d3d9.dll.enb_backup first.
2. Copy dxvk.conf from this folder next to it.
To undo: delete d3d9.dll and dxvk.conf (and rename your ENB backup back to d3d9.dll).
